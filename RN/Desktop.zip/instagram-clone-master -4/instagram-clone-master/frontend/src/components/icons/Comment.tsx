import React from 'react';
import {  ModeCommentOutlined } from '@mui/icons-material';

export const CommentIcon = () => <ModeCommentOutlined className='cursor-pointer'/>
