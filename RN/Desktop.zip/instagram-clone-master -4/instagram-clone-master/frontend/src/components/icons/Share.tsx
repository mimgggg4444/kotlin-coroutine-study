import React from 'react';
import { SendOutlined } from '@mui/icons-material';

export const ShareIcon = () => <SendOutlined className='cursor-pointer'/>
