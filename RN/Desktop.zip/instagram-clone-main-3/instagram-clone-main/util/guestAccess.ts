const guestAccess = () => {
  const email = 'place your guest account details here';
  const password = 'place your guest account details here';

  return { email, password };
};

export default guestAccess;
